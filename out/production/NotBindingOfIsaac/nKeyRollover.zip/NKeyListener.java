
import java.awt.event.*;

public class NKeyListener implements KeyListener
{
  private NKeyList keys = new NKeyList();
  
  public void keyPressed(KeyEvent evt)
  {
    char c = evt.getKeyChar();
    keys.add(c);
  }
  
  public void keyReleased(KeyEvent evt)
  {
	char c = evt.getKeyChar();
	keys.remove(c);
  }
  
  
  // not needed
  public void keyTyped(KeyEvent evt) {}
  
  
}
