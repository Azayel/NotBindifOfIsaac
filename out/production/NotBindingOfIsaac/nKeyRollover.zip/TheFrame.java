
import java.awt.event.*;
import javax.swing.*;

public class TheFrame extends JFrame implements KeyListener 
{
  public NKeyList keys = new NKeyList();
  
  private PrintThread thread;
	
	
  public TheFrame()
  {
	this.setDefaultCloseOperation(EXIT_ON_CLOSE);
	this.addKeyListener(this);
	
	PrintThread thread = new PrintThread(keys);
	thread.start();
	
	init();
  }
  
  public void init()
  {
	this.setSize(600,400);
	this.setLocation(200,200);
  }

  /**
   *  needed for N Key Rollover
   */
  public void keyPressed(KeyEvent evt)
  {
    char c = evt.getKeyChar();
    keys.add(c);
  }
  
  public void keyReleased(KeyEvent evt)
  {
	char c = evt.getKeyChar();
	keys.remove(c);
  }
  
  
  // not needed
  public void keyTyped(KeyEvent evt) {}

  
}
