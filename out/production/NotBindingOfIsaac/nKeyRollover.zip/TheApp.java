
public class TheApp 
{
  private TheFrame frame = null;
  
  public TheApp()
  {
	frame = new TheFrame();
	frame.validate();
	frame.setVisible(true);
  }
  
  public static void main(String[] args)
  {
	new TheApp();
  }
}
